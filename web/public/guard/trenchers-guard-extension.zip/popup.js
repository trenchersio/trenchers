(() => {
  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  async function render() {
    const s = await chrome.storage.local.get(["settings", "stats", "phishingAt"]);
    const st = s.stats ?? {}, set = s.settings ?? { on: true, every: false };
    $("checked").textContent = String(st.checked ?? 0);
    $("flagged").textContent = String(st.flagged ?? 0);
    $("rejected").textContent = String(st.rejected ?? 0);
    $("on").checked = set.on;
    $("every").checked = set.every;
    $("state").textContent = set.on ? "On: checking every wallet request" : "Paused";
    $("state").className = set.on ? "on" : "off";
    $("list").textContent = s.phishingAt ? `Phishing list updated ${new Date(s.phishingAt).toLocaleDateString()}` : "Phishing list: downloading\u2026";
  }
  async function save() {
    await chrome.storage.local.set({ settings: { on: $("on").checked, every: $("every").checked } });
    void render();
  }
  $("on").addEventListener("change", save);
  $("every").addEventListener("change", save);
  $("refresh").addEventListener("click", async () => {
    $("list").textContent = "Updating\u2026";
    await chrome.runtime.sendMessage({ type: "refresh" });
    void render();
  });
  void render();
})();
