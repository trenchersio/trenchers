(() => {
  // ../engine/src/guard-scan.ts
  var RANK = { ok: 0, info: 1, warn: 2, danger: 3 };
  var HUGE = 2n ** 128n;
  var short = (a) => /^0x[0-9a-fA-F]{40}$/.test(a) ? `${a.slice(0, 6)}\u2026${a.slice(-4)}` : a;
  var lc = (s) => String(s ?? "").toLowerCase();
  var name = (ctx2, a) => ctx2.names?.[lc(a)] ?? short(a);
  var word = (data, i) => data.slice(10 + i * 64, 10 + (i + 1) * 64);
  var addrAt = (data, i) => `0x${word(data, i).slice(24)}`;
  var uintAt = (data, i) => {
    const w = word(data, i);
    return w.length === 64 ? BigInt(`0x${w}`) : 0n;
  };
  var big = (v) => {
    try {
      if (typeof v === "bigint") return v;
      if (typeof v === "number") return BigInt(Math.trunc(v));
      const s = String(v ?? "0");
      return BigInt(s === "" ? "0" : s);
    } catch {
      return 0n;
    }
  };
  var amount = (v) => v >= HUGE ? "an unlimited amount" : v === 0n ? "nothing" : `${v.toLocaleString("en-US")} units`;
  var eth = (wei) => {
    const s = (Number(wei) / 1e18).toPrecision(4);
    return `${Number(s)} ETH`;
  };
  var SEL = {
    approve: "0x095ea7b3",
    increaseAllowance: "0x39509351",
    setApprovalForAll: "0xa22cb465",
    transfer: "0xa9059cbb",
    transferFrom: "0x23b872dd",
    safeTransferFrom: "0x42842e0e",
    permit2Approve: "0x87517c45",
    multicall: "0xac9650d8"
  };
  function spenderRisk(ctx2, spender) {
    const s = lc(spender);
    if (ctx2.flagged?.has(s)) return { level: "danger", line: `${short(spender)} is a known drainer address.` };
    if (ctx2.trusted?.has(s)) return { level: "info", line: `${name(ctx2, spender)} is a contract we recognise.` };
    return { level: "warn", line: `We don't recognise ${short(spender)}. Only approve contracts from sites you trust.` };
  }
  function scanTx(tx, ctx2 = {}) {
    const to = lc(tx.to), data = lc(tx.data ?? tx.input ?? "0x"), value = big(tx.value);
    const sel = data.slice(0, 10);
    if (!to) return { level: "warn", kind: "deploy", title: "Deploys a new contract", lines: ["This creates a contract from your wallet. Only do this if you meant to."] };
    if (ctx2.flagged?.has(to)) return { level: "danger", kind: "flagged", title: "This sends to a known drainer", lines: [`${short(to)} is on our list of drainer addresses. Reject it.`] };
    if (data === "0x" || data === "") {
      return value > 0n ? { level: "info", kind: "send", title: `Sends ${eth(value)}`, lines: [`To ${name(ctx2, to)}. Check the address is exactly the one you meant.`] } : { level: "ok", kind: "empty", title: "An empty transaction", lines: ["It moves nothing."] };
    }
    if (sel === SEL.approve || sel === SEL.increaseAllowance) {
      const spender = addrAt(data, 0), amt = uintAt(data, 1);
      if (amt === 0n && sel === SEL.approve) return { level: "ok", kind: "revoke", title: "Removes an approval", lines: [`${name(ctx2, to)} will no longer let ${short(spender)} spend it. This makes you safer.`], spender, token: to };
      const r2 = spenderRisk(ctx2, spender), unlimited = amt >= HUGE;
      const level = r2.level === "danger" ? "danger" : unlimited && r2.level !== "info" ? "danger" : unlimited || r2.level === "warn" ? "warn" : "info";
      return {
        level,
        kind: "approve",
        spender,
        token: to,
        title: unlimited ? `Lets ${short(spender)} spend ALL your ${name(ctx2, to)}, forever` : `Lets ${short(spender)} spend ${amount(amt)} of ${name(ctx2, to)}`,
        lines: [r2.line, unlimited ? "It never expires. If that contract is malicious, it can take every token of this kind, now or later." : "It stays until you revoke it."]
      };
    }
    if (sel === SEL.setApprovalForAll) {
      const op = addrAt(data, 0), on = uintAt(data, 1) !== 0n;
      if (!on) return { level: "ok", kind: "revoke", title: "Removes a collection-wide approval", lines: [`${short(op)} can no longer move your NFTs from ${name(ctx2, to)}.`], spender: op, token: to };
      const r2 = spenderRisk(ctx2, op);
      return {
        level: r2.level === "info" ? "warn" : "danger",
        kind: "approve-all",
        spender: op,
        token: to,
        title: `Hands over EVERY NFT you hold in ${name(ctx2, to)}`,
        lines: [r2.line, "This is how most NFT drains start: one approval, then everything in the collection is moved."]
      };
    }
    if (sel === SEL.permit2Approve) {
      const token = addrAt(data, 0), spender = addrAt(data, 1), amt = uintAt(data, 2), r2 = spenderRisk(ctx2, spender);
      return {
        level: amt >= HUGE / 2n ** 32n && r2.level !== "info" ? "danger" : "warn",
        kind: "permit2",
        spender,
        token,
        title: `Permit2: lets ${short(spender)} spend ${amount(amt)} of ${name(ctx2, token)}`,
        lines: [r2.line]
      };
    }
    if (sel === SEL.transfer) {
      const dest = addrAt(data, 0), amt = uintAt(data, 1);
      return { level: ctx2.flagged?.has(lc(dest)) ? "danger" : "info", kind: "transfer", token: to, title: `Sends ${amount(amt)} of ${name(ctx2, to)}`, lines: [`To ${short(dest)}. Check the address is exactly the one you meant: look-alike addresses are a common trick.`] };
    }
    if (sel === SEL.transferFrom || sel === SEL.safeTransferFrom) {
      const from = addrAt(data, 0), dest = addrAt(data, 1);
      return { level: "info", kind: "transfer", token: to, title: `Moves a token from ${short(from)}`, lines: [`To ${short(dest)}.`] };
    }
    const r = ctx2.trusted?.has(to) ? { level: "info", line: `${name(ctx2, to)} is a contract we recognise.` } : { level: "info", line: `A call to ${short(to)} we can't read in detail. Make sure you trust the site.` };
    return { level: value > 0n && r.level !== "info" ? "warn" : r.level, kind: "call", title: value > 0n ? `Calls a contract and sends ${eth(value)}` : "Calls a contract", lines: [r.line] };
  }
  function scanTyped(json, ctx2 = {}) {
    let t;
    try {
      t = typeof json === "string" ? JSON.parse(json) : json;
    } catch {
      return { level: "warn", kind: "typed", title: "A signature we can't read", lines: ["Only sign it if you fully trust this site."] };
    }
    const p = t?.primaryType ?? "", m = t?.message ?? {}, dom = t?.domain ?? {};
    const contract = lc(dom.verifyingContract);
    if (p === "Permit") {
      const spender = String(m.spender ?? ""), v = big(m.value), r = spenderRisk(ctx2, spender);
      return {
        level: r.level === "info" && v < HUGE ? "warn" : "danger",
        kind: "permit",
        spender,
        token: contract,
        title: `Permit: lets ${short(spender)} spend ${amount(v)} of ${dom.name ?? name(ctx2, contract)}`,
        lines: ["It costs no gas and looks like a sign-in, but it gives away your tokens. This was the biggest single way people were drained in 2025.", r.line]
      };
    }
    if (p === "PermitSingle" || p === "PermitBatch" || p === "PermitTransferFrom" || p === "PermitBatchTransferFrom" || p === "PermitWitnessTransferFrom") {
      const spender = String(m.spender ?? ""), r = spenderRisk(ctx2, spender);
      return { level: r.level === "info" ? "warn" : "danger", kind: "permit2", spender, title: `Permit2 signature: lets ${short(spender)} move your tokens`, lines: ["A gasless signature that can move tokens you've approved for Permit2.", r.line] };
    }
    if (p === "OrderComponents" || p === "Order" || p === "BulkOrder" || p === "Root") {
      return { level: "warn", kind: "listing", title: "Lists your NFTs or tokens for sale", lines: ['Check the price and the items. Fake "listings" at almost zero are a common drain.'] };
    }
    if (/delegat|authoriz/i.test(p)) return { level: "danger", kind: "delegation", title: "Hands control of your wallet to a contract", lines: ["This delegates your account. A malicious contract could then move everything you hold."] };
    return { level: "info", kind: "typed", title: `Signs a "${p || "message"}" message`, lines: [`For ${dom.name ?? "an app"}. It doesn't look like a transfer or approval.`] };
  }
  var hexText = (h) => {
    try {
      if (!/^0x[0-9a-fA-F]*$/.test(h)) return h;
      const b = h.slice(2).match(/../g)?.map((x) => parseInt(x, 16)) ?? [];
      const s = new TextDecoder().decode(new Uint8Array(b));
      return /[\x00-\x08\x0e-\x1f]/.test(s) ? null : s;
    } catch {
      return null;
    }
  };
  function edits(a, b) {
    const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
    for (let j = 1; j <= b.length; j++) d[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return d[a.length][b.length];
  }
  var BRANDS = ["trenchers.io", "uniswap.org", "opensea.io", "metamask.io", "pons.family", "robinhood.com", "blur.io", "aave.com", "lido.fi", "coinbase.com", "rabby.io", "phantom.app", "etherscan.io"];
  function scanOrigin(origin, ctx2 = {}) {
    if (!origin) return null;
    let host = "";
    try {
      host = new URL(origin).hostname.toLowerCase();
    } catch {
      return null;
    }
    const bare = host.replace(/^www\./, "");
    if (ctx2.phishing?.has(bare) || ctx2.phishing?.has(host)) return { level: "danger", kind: "phishing", title: `${bare} is a known phishing site`, lines: ["Close this tab. Nothing it asks you to sign is safe."] };
    if (bare.split(".").some((p) => p.startsWith("xn--"))) return { level: "warn", kind: "lookalike", title: `${bare} uses look-alike letters`, lines: ["The address may imitate a real site with letters from another alphabet."] };
    for (const b of ctx2.brands ?? BRANDS) {
      if (bare === b || bare.endsWith(`.${b}`)) return null;
      const [n] = b.split("."), [m] = bare.split(".");
      const typo = m !== n && n.length >= 5 && m.length >= 4 && edits(m, n) <= (n.length > 6 ? 2 : 1);
      const borrowed = !typo && n.length >= 5 && bare.includes(n);
      if (typo || borrowed) return { level: typo ? "danger" : "warn", kind: "lookalike", title: `${bare} ${typo ? "looks like" : "uses the name of"} ${b}, but isn't it`, lines: [`If you meant to visit ${b}, close this tab and type the address yourself.`] };
    }
    return null;
  }
  function scan(req, ctx2 = {}) {
    const out = [];
    const o = scanOrigin(req.origin, ctx2);
    if (o) out.push(o);
    const p = req.params ?? [];
    switch (req.method) {
      case "eth_sendTransaction":
        out.push(scanTx(p[0] ?? {}, ctx2));
        break;
      case "wallet_sendCalls": {
        const calls = p[0]?.calls ?? [];
        calls.forEach((c) => out.push(scanTx(c, ctx2)));
        if (calls.length > 1) out.push({ level: "info", kind: "batch", title: `${calls.length} actions in one go`, lines: ["Every one of them runs if you approve."] });
        break;
      }
      case "eth_signTypedData":
      case "eth_signTypedData_v3":
      case "eth_signTypedData_v4": {
        const j = typeof p[0] === "string" && String(p[0]).trim().startsWith("{") ? p[0] : p[1];
        out.push(scanTyped(j, ctx2));
        break;
      }
      case "eth_sign":
        out.push({ level: "danger", kind: "blind", title: "A blind signature", lines: ["eth_sign can sign anything, including a transaction that empties your wallet. Legitimate sites almost never ask for it."] });
        break;
      case "personal_sign": {
        const raw = String((typeof p[0] === "string" && String(p[0]).startsWith("0x") && String(p[0]).length !== 42 ? p[0] : p[1]) ?? "");
        if (/^0x[0-9a-fA-F]{64}$/.test(raw)) {
          out.push({ level: "danger", kind: "blind", title: "Signs an unreadable hash", lines: ["You can't see what this signature approves. Only sign it if you fully trust the site."] });
          break;
        }
        const text = hexText(raw);
        out.push(text === null ? { level: "warn", kind: "sign", title: "Signs data we can't read", lines: ["Only sign it if you fully trust this site."] } : { level: "ok", kind: "sign", title: "Signs a message", lines: [`"${text.slice(0, 160)}${text.length > 160 ? "\u2026" : ""}"`, "A plain message can't move your funds on its own."] });
        break;
      }
      case "eth_signAuthorization":
      case "wallet_signAuthorization":
      case "eth_signAuthorizationRequest":
        out.push({ level: "danger", kind: "delegation", title: "Hands control of your wallet to a contract (EIP-7702)", lines: ["After this, the contract can act as your wallet. Only do it for a wallet upgrade you started yourself."] });
        break;
      default:
        return { level: out[0]?.level ?? "ok", findings: out };
    }
    out.sort((a, b) => RANK[b.level] - RANK[a.level]);
    return { level: out[0]?.level ?? "ok", findings: out };
  }
  var CHECKED = /* @__PURE__ */ new Set(["eth_sendTransaction", "wallet_sendCalls", "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4", "eth_sign", "personal_sign", "eth_signAuthorization", "wallet_signAuthorization", "eth_signAuthorizationRequest"]);

  // src/inject.ts
  var ctx = { trusted: /* @__PURE__ */ new Set(), flagged: /* @__PURE__ */ new Set(), names: {} };
  var settings = { on: true, every: false };
  var originFlag = null;
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.data?.__tg !== "lists") return;
    const d = e.data;
    if (d.trusted) {
      ctx.trusted = new Set(Object.keys(d.trusted));
      ctx.names = d.trusted;
    }
    if (d.flagged) ctx.flagged = new Set(d.flagged);
    if (d.settings) settings = d.settings;
    if (d.phishing) originFlag = { level: "danger", kind: "phishing", title: `${d.host} is a known phishing site`, lines: ["Close this tab. Nothing it asks you to sign is safe."] };
  });
  var tell = (type, extra = {}) => window.postMessage({ __tg: "event", type, ...extra }, "*");
  var COLORS = { ok: "#39FF88", info: "#6EC8FF", warn: "#FFB020", danger: "#FF4D4D" };
  var LABEL = { ok: "Looks fine", info: "Check the details", warn: "Be careful", danger: "This could drain your wallet" };
  var esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  function ask(level, findings) {
    return new Promise((done) => {
      const host = document.createElement("div");
      host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647";
      const root = host.attachShadow({ mode: "closed" });
      const c = COLORS[level];
      root.innerHTML = `<style>
      *{box-sizing:border-box;margin:0}
      .bg{position:fixed;inset:0;background:rgba(5,7,6,.72);backdrop-filter:blur(3px);display:grid;place-items:center;padding:16px;font:14px/1.45 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:#E8ECE9}
      .card{width:min(460px,100%);background:#0F1211;border:1px solid #232826;border-top:3px solid ${c};border-radius:14px;padding:20px;box-shadow:0 24px 80px rgba(0,0,0,.6);max-height:90vh;overflow:auto}
      .top{display:flex;align-items:center;gap:10px;margin-bottom:14px}
      .shield{width:28px;height:28px;flex:none}
      .brand{font:600 11px/1 ui-monospace,Menlo,monospace;letter-spacing:.14em;color:#8A938E;text-transform:uppercase}
      .lvl{font-weight:700;font-size:18px;color:${c}}
      .f{border:1px solid #232826;border-radius:10px;padding:12px;margin-top:10px;background:#121514}
      .f b{display:block;font-size:15px;margin-bottom:4px}
      .f p{color:#AEB6B1;font-size:13px;margin-top:3px}
      .dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:8px;vertical-align:1px}
      .row{display:flex;gap:10px;margin-top:18px}
      button{flex:1;font:600 14px/1 inherit;font-family:inherit;padding:12px;border-radius:10px;cursor:pointer;border:1px solid #2C322F}
      .no{background:${c};color:#0B0D0C;border-color:${c}}
      .yes{background:transparent;color:#AEB6B1}
      .yes:disabled{opacity:.4;cursor:default}
      label{display:flex;gap:8px;align-items:flex-start;margin-top:14px;font-size:13px;color:#AEB6B1;cursor:pointer}
      .site{font:12px ui-monospace,Menlo,monospace;color:#8A938E;margin-top:12px;word-break:break-all}
    </style>
    <div class="bg" role="dialog" aria-modal="true" aria-label="Trenchers Guard warning"><div class="card">
      <div class="top"><svg class="shield" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2"><path d="M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5l-8-3Z"/><path d="M9 12l2 2 4-4"/></svg>
        <div><div class="brand">Trenchers Guard</div><div class="lvl">${LABEL[level]}</div></div></div>
      ${findings.map((f) => `<div class="f"><b><span class="dot" style="background:${COLORS[f.level]}"></span>${esc(f.title)}</b>${f.lines.map((l) => `<p>${esc(l)}</p>`).join("")}</div>`).join("")}
      ${level === "danger" ? `<label><input type="checkbox" class="ok"> I understand the risk and still want to open my wallet.</label>` : ""}
      <div class="site">${esc(location.host)}</div>
      <div class="row"><button class="no">Reject</button><button class="yes" ${level === "danger" ? "disabled" : ""}>Continue to wallet</button></div>
    </div></div>`;
      const yes = root.querySelector(".yes"), no = root.querySelector(".no");
      root.querySelector(".ok")?.addEventListener("change", (e) => {
        yes.disabled = !e.target.checked;
      });
      const onKey = (e) => {
        if (e.key === "Escape") {
          e.stopPropagation();
          finish(false);
        }
      };
      const finish = (v) => {
        window.removeEventListener("keydown", onKey, true);
        host.remove();
        done(v);
      };
      window.addEventListener("keydown", onKey, true);
      no.addEventListener("click", () => finish(false));
      yes.addEventListener("click", () => finish(true));
      (document.body ?? document.documentElement).appendChild(host);
      no.focus();
    });
  }
  async function check(args) {
    if (!settings.on || !args || !CHECKED.has(args.method)) return;
    let r;
    try {
      r = scan({ ...args, origin: location.origin }, ctx);
    } catch {
      return;
    }
    if (originFlag) {
      r.findings.unshift(originFlag);
      r.level = "danger";
    }
    tell("checked", { level: r.level });
    const show = r.level === "danger" || r.level === "warn" || settings.every && r.findings.length;
    if (!show) return;
    let go;
    try {
      go = await ask(r.level, r.findings);
    } catch {
      go = window.confirm(`Trenchers Guard: ${LABEL[r.level]}

${r.findings.map((f) => `${f.title}
${f.lines.join(" ")}`).join("\n\n")}

Open your wallet anyway?`);
    }
    tell(go ? "continued" : "rejected", { level: r.level });
    if (!go) throw Object.assign(new Error("Trenchers Guard: you rejected this request."), { code: 4001 });
  }
  function wrap(p) {
    if (!p || typeof p.request !== "function" || p.__trenchersGuard) return;
    const orig = p.request;
    const guarded = async function(args) {
      await check(args);
      return orig.call(this ?? p, args);
    };
    try {
      Object.defineProperty(p, "request", { value: guarded, configurable: true, writable: true });
      Object.defineProperty(p, "__trenchersGuard", { value: true });
    } catch {
      tell("unprotected");
    }
    for (const m of ["sendAsync", "send"]) {
      const f = p[m];
      if (typeof f !== "function") continue;
      try {
        Object.defineProperty(p, m, { configurable: true, writable: true, value: function(a, cb) {
          const req = typeof a === "string" ? { method: a, params: cb } : a;
          if (!req || !CHECKED.has(req.method)) return f.call(this ?? p, a, cb);
          const run = check(req).then(() => f.call(this ?? p, a, cb));
          if (typeof cb === "function") {
            run.catch((e) => cb(e));
            return void 0;
          }
          return run;
        } });
      } catch {
      }
    }
  }
  try {
    let current = window.ethereum;
    wrap(current);
    const d = Object.getOwnPropertyDescriptor(window, "ethereum");
    if (!d || d.configurable) {
      Object.defineProperty(window, "ethereum", {
        configurable: true,
        enumerable: true,
        get: () => current,
        set: (v) => {
          current = v;
          wrap(v);
        }
      });
    }
  } catch {
  }
  window.addEventListener("eip6963:announceProvider", (e) => {
    wrap(e.detail?.provider);
  });
  for (const ms of [0, 50, 300, 1500]) setTimeout(() => wrap(window.ethereum), ms);
  tell("ready");
})();
